﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DraggingShapes
{
    public partial class Form1 : Form
    {

        float W = 0;
        float H = 0;
        float X = 200;
        float Y = 200;

        bool isMouseDown = false;

        Graphics s2;
        Graphics trans;
        Pen p2 = new Pen(Color.Green, 5);

        public Form1()
        {
            InitializeComponent();
        }

        private void Canvas_Paint(object sender, PaintEventArgs e)
        {
                s2 = Canvas.CreateGraphics();
                s2.DrawEllipse(p2, X, Y, W, H);
                

        }

        private void txtradius_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                W = float.Parse(txtradius.Text) * 2;
                H = float.Parse(txtradius.Text) * 2;
            }

            catch (Exception)
            {

            }
        }

        private void Draw_Click(object sender, EventArgs e)
        {
            if (txtradius.Text == "0")
            {
                MessageBox.Show("Please input Valid Number.");
            }
            else
            {
                Canvas.Refresh();
                btnDown.Enabled = true;
                btnLeft.Enabled = true;
                btnRight.Enabled = true;
                btnUp.Enabled = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Canvas.Enabled = false;
            s2.Clear(Color.Black);
            btnDown.Enabled = false;
            btnLeft.Enabled = false;
            btnRight.Enabled = false;
            btnUp.Enabled = false;
        }

        private void Canvas_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMouseDown == true)
            {
                X = e.X;
                Y = e.Y;

                Canvas.Refresh();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Y -= 10;
            Canvas.Refresh();
        }

        private void btnDown_Click(object sender, EventArgs e)
        {
            Y += 10;
            Canvas.Refresh();
        }

        private void btnRight_Click(object sender, EventArgs e)
        {
            X += 10;
            Canvas.Refresh();
        }

        private void btnLeft_Click(object sender, EventArgs e)
        {
            X -= 10;
            Canvas.Refresh();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Canvas_MouseDown(object sender, MouseEventArgs e)
        {
            isMouseDown = true;
        }

        private void Canvas_MouseUp(object sender, MouseEventArgs e)
        {
            isMouseDown = false;
        }
    }
    }

